package com.example.application.endpoint;

public class CalendarAvailabilityEndpoint {
}
